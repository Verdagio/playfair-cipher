package ie.gmit.sw.ai;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Grams {
	
	private String fileName;
	private Map<String, Double> nGrams = new HashMap<String, Double>();
	private int count;
	
	public Grams(String fileName) {
		this.fileName = fileName;
		this.count = 0;
	}// Constructor

	public Map<String, Double> loadNGrams()  throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(fileName))));
		String line = "";
		System.out.println("Loading n-grams...");
		while((line = br.readLine()) != null) {
			nGrams.put(line.split(" ")[0], Double.parseDouble(line.split(" ")[1]));
			count++;
		}
		System.out.println("Sucessfully loaded n-grams...");
		br.close();	
		return this.nGrams;
	}
	
	public int getCount() {
		return this.count;
	}
	
}
