package ie.gmit.sw.ai;

import java.util.HashMap;
import java.util.LinkedList;

public class SimulatedAnnealing {
	
	private LinkedList<String> shingles;
	private Playfair pf;
	private Grams g;
	private String next;
	
	private Key key;
	private String parent;
	private double parentScore;
	private String child;
	private double childScore;
	private String bestKey;
	private double bestScore;
	
	private int tempurature;
	private int transitions;
	private int step;
	private double fitness;
	
	private HashMap<String, Double> shingleMap; 
	
	public SimulatedAnnealing(int tempurature, int transitions, int steps, String key) {
		super();
		this.g = new Grams("4grams.txt");
		this.pf = new Playfair();
		this.key = Key.keyInstance(key);
		this.shingles = new LinkedList<String>();
		this.tempurature = tempurature;
		this.transitions = transitions;
		this.step = steps;
		this.fitness = 0;
		this.parentScore = 0;
		this.childScore = 0;
		this.bestScore = -99999;
	}// construct
	
	public void generateShingles(String cipherText) {
		for(int index = 0; index <= cipherText.length() - 4; index++) {
			this.shingles.add(cipherText.substring(index, index + 4));
			//return generateShingles(cipherText, index++);
		}
		//return 0;
		
	}// recursive shingler 

	public void annealing(String cipherText) throws Throwable {
		double temp = 0;
		
		shingleMap =  (HashMap<String, Double>) g.loadNGrams();
		
		parent = key.generateKey();
		this.next = pf.decrypt(parent, cipherText);
		generateShingles(cipherText);
		

		temp = scoreText(shingles.toArray(new String[shingles.size()]));

		System.out.println("4gram len: " + g.getCount());
		this.fitness = temp;
		System.out.println("Score: "+ this.fitness);
		for(int i = tempurature; i > 0; i-= step) {
			//transitions(cipherText, transitions);
			for (int j = 0; j < transitions; j++) {
				child = key.shuffleKey(parent);
				double delta;
				next = pf.decrypt(child, cipherText);
				generateShingles(cipherText);
				
				childScore = scoreText(shingles.toArray(new String[shingles.size()]));
				
				delta = childScore - fitness;	
				//System.out.println(delta);

				if(delta < 0) {
					this.setParent(child);
					this.setParentScore(childScore);
				} else {
					if(Math.exp((delta/tempurature)) < -0.5) { 
						this.setParent(child);
						this.setParentScore(childScore);
					}
				}
				if(parentScore > bestScore) {
					bestScore = parentScore;
					bestKey = parent;
					System.out.printf("\n%d best Score: %f0.3\tFor Key: %s\n", j, bestScore, bestKey);
					if(bestKey.equalsIgnoreCase("THEQUICKBROWNFXMPDVRLAZYDGS")) {
						Thread.sleep(5000);
					}
				}			}
		}//tempurature
		
	}// annealing
	
	public double scoreText(String[] shingles) {
		double score = 0;
		
		for(int index = 0; index < shingles.length; index++) {
			if(shingleMap.keySet().contains(shingles[index])) {
				score += Math.log10(probability(shingleMap, shingles[index]));
				//System.out.println(score);
			}
		}
		
		
		return score;
		
	}
	
	public int transitions(String cipherText,  int index) throws Throwable {	
		if(index > 0) {
				child = key.shuffleKey(parent);
				double delta;
				this.next = pf.decrypt(child, cipherText);
				generateShingles(cipherText);
				
				for(String shingle : this.shingles) { 
					if(shingleMap.keySet().contains(shingle)) {
						this.childScore += probability(shingleMap, shingle);  
					}// if
				}//for
				
				delta = this.childScore - this.fitness;	
				if(delta >= 0) {
					this.setParent(child);
					this.setParentScore(childScore);
				} else {
					if(Math.exp((delta/tempurature)) > 0.5) {
						this.setParent(child);
						this.setParentScore(childScore);
					}
				}
				if(parentScore > bestScore) {
					setBestScore(parentScore);
					setBestKey(parent);
					System.out.printf("%d best Score: %f0.3\tFor Key: %s\n%s", index, getBestScore(), getBestKey(), pf.getPlainText());
				}
				return transitions(pf.getPlainText(), index--);
		}
			return 0;
		
	}
	
	public double probability(HashMap <String, Double> map, String shingle) {
		//System.out.println(shingleMap.get(shingle).doubleValue() /  g.getCount());
		return  shingleMap.get(shingle).doubleValue() / g.getCount();
	}

	public String getParent() {
		return parent;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public double getParentScore() {
		return parentScore;
	}

	public void setParentScore(double parentScore) {
		this.parentScore = parentScore;
	}

	public String getChild() {
		return child;
	}

	public void setChild(String child) {
		this.child = child;
	}

	public double getChildScore() {
		return childScore;
	}

	public void setChildScore(double childScore) {
		this.childScore = childScore;
	}

	public String getBestKey() {
		return bestKey;
	}

	public void setBestKey(String bestKey) {
		this.bestKey = bestKey;
	}

	public double getBestScore() {
		return bestScore;
	}

	public void setBestScore(double bestScore) {
		this.bestScore = bestScore;
	}

	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}
	
	
	
}


